import React from "react";
import style from './RegistrationPage.module.css'
import CoverPage from "./CoverPage/CoverPage";
import RegistrationForm from "./FormPage/RegistrationForm";
import {useRef, useState} from "react";
import {useNavigate } from 'react-router-dom';

import {Schema} from "rsuite";
import {setUser} from "../../redux/reducers/authReducer";
import {useDispatch, useSelector} from "react-redux";

//state
const RegistrationPage = () => {
    // const navigate = useNavigate()

    const dispatch = useDispatch()

    let isRegistrated = useSelector((state) => state.authReducer.isRegistrated)

    const {StringType} = Schema.Types;
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        // name: "",
        email:'',
        password: ''
    });
    const handleSubmit = () => {
        if (!formRef.current.check()) {
            return;
        }
        // registerAPI.postsUsers({...formValue})
        dispatch(setUser({...formValue}))
    }
    // const redirect = () => {
    //     navigate('/login')
    // }
    const model = Schema.Model({
        // name: StringType()
        //     .isRequired('This field is required.')
        //     .minLength(2, 'Name is too short'),
        password: StringType()
            .minLength(8, 'Password is too short')
            .isRequired('This field is required.'),
        email:StringType()
            .isEmail('Enter valid email')
            .isRequired('This field is required')
    });
    return(
        <div className={style.body}>
            <div className={style.container}>
                <CoverPage/>
                <RegistrationForm
                    formValue = {formValue}
                    setFormValue = {setFormValue}
                    formError={formError}
                    setFormError={setFormError}
                    formRef={formRef}
                    handleSubmit = {handleSubmit}
                    formModel = {model}

                    isRegistrated = {isRegistrated}
                />
            </div>
        </div>
    )
}

export default RegistrationPage