import React from "react";
import style from './CoverPage.module.css'
import img from './frontImg.jpg'

const CoverPage = () => {
    return(
        <div className={style.cover}>
            <div className={style.front}>
                <div className={style.text}>
                    <img src={img} alt=""/>
                    <span className={style.text_one}>Every new friend is a  new adventure</span>
                    <span className={style.text_two}>Let's get connected</span>
                </div>
            </div>
        </div>
    )
}

export default CoverPage