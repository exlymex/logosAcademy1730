import React from 'react'

const MainPage = () => {
    return(
        <div>Main Page</div>
    )
}
export default MainPage