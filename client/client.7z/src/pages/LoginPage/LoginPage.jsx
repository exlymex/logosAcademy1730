import React from "react";
import style from './LoginPage.module.css'
import CoverPage from "./CoverPage/CoverPage";
import FormPage from "./FormPage/FormPage";
import {useRef, useState} from "react";
import {Schema} from "rsuite";
import {loginUser} from "../../redux/reducers/authReducer";
import {useDispatch, useSelector} from "react-redux";
import {useNavigate} from "react-router-dom";
// import "rsuite/dist/rsuite.min.css";

const LoginPage = () => {
    const dispatch = useDispatch()
    const isAuthentificated = useSelector(state => state.authReducer.isAuth)

    const navigate = useNavigate()

    const redirect = () => {
        navigate('/main')
    }
    const {StringType} = Schema.Types;
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        email: "",
        password: "",
    });
    // {isAuthentificated && redirect()}

    const handleSubmit = () => {
        if (!formRef.current.check()) {
            return;
        }
        dispatch(loginUser({...formValue}))

    }
    const model = Schema.Model({
        email: StringType()
            .isRequired('This field is required.')
            .isEmail( 'Name is too short'),
        password: StringType()
            .minLength(8, 'Password is too short')
            .isRequired('This field is required.'),
    });
    return(
        <div className={style.body}>
            <div className={style.container}>
                <CoverPage/>
                <FormPage
                    formValue = {formValue}
                    setFormValue = {setFormValue}
                    formError={formError}
                    setFormError={setFormError}
                    formRef={formRef}
                    handleSubmit = {handleSubmit}
                    formModel = {model}
                />
            </div>
        </div>
    )
}

export default LoginPage