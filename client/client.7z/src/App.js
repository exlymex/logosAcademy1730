import './App.css';
import {BrowserRouter, Route, Routes} from "react-router-dom";
import LoginPage from "./pages/LoginPage/LoginPage";
import {RouteConst} from "./common/RouteConst";
import RegistrationPage from "./pages/RegistrationPage/RegistrationPage";
import Header from "./components/Header/Header";
import Router from "./navigation/Router";
import {useEffect} from "react";
import {actionUsers} from "./redux/actionsCreator/authCreator";
import {useDispatch} from "react-redux";


const App = () => {
    const dispatch = useDispatch()

    useEffect(() => {
        const token = localStorage.getItem('userToken')
        const userID = localStorage.getItem('userID')
        dispatch(actionUsers.setUsers(userID,token))
    },[] )

  return (
      <>
          <Router/>
      </>

  )
}

export default App;
