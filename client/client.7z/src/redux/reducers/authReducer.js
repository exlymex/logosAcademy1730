import {actionsForAuth, actionUsers} from "../actionsCreator/authCreator";
import {loginAPI, registerAPI} from "../../api/api";
import {useEffect} from "react";

const initialState = {
    token:null,
    userID:null,
    isAuth:false,
    isRegistrated:false
}
const setAuthAction = ({userID, token}) => {
    return dispatch => {
        localStorage.setItem('userToken',JSON.stringify(token))
        localStorage.setItem('userID',JSON.stringify(userID))
        dispatch(actionUsers.setUsers(userID,token))
    }
}
    // localStorage.setItem('userData',JSON.stringify({
    //     token,userID
    // }))
export const authReducer = (state = initialState,action) => {
    switch(action.type){
        case actionsForAuth.SET_USERS:
            return({
                ...state,
                token:action.token,
                userID: action.id,
                isAuth: true
            })
        case actionsForAuth.SET_REGISTRATION:
            return {
                ...state,
                isRegistrated:true
            }
        case actionsForAuth.SET_ERRORS:
            return{
                ...state,
                errorUsers: action.error
            }
        default:
            return state

    }
}
export const setUser = ({email,password}) =>  (dispatch) => {
    registerAPI.postsUsers({email,password})
        .then(response => {
           if(response.status === 201){
                dispatch(actionUsers.setRegistrationMessage())
           }
        })
}
export const loginUser = ({email,password}) => async (dispatch) => {
    await loginAPI.loginUsers({email,password})
        .then((response) => {
            dispatch(setAuthAction({...response}))
        })

}



export default authReducer