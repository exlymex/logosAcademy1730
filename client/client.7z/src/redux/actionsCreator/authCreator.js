export const actionsForAuth = {
    SET_USERS : "SET_USERS",
    SET_ERRORS : "SET_ERRORS",
    SET_REGISTRATION: 'SET_REGISTRATION'
}
export const actionUsers = {
    setUsers : (token,id) => ({type:actionsForAuth.SET_USERS,token,id}),
    setRegistrationMessage : () => ({type:actionsForAuth.SET_REGISTRATION}),
    setErrors : (errors) => ({type:actionsForAuth.SET_ERRORS,errors})
}
