export const RouteConst = {
    MAIN:'/main',
    LOGIN:'/login',
    ADMIN:'/admin',
    REGISTRATION:'/registration'
}