import styles from "./Header.module.css";
import { Link } from "react-router-dom";
import { RouteConst } from "../../common/RouteConst";

const Header = () => {
    return (
        <div className={styles.container}>
            <Link className={styles.link} to=''>
                Another
            </Link>
            <Link className={styles.link} to=''>
                Yo
            </Link>
        </div>
    );
};

export default Header;