import axios from "axios";

const instance = axios.create( {
    headers: {
        "Content-Type": "application/json"
    }
})
export const registerAPI = {
    postsUsers({email,password}){
       return instance.post('/api/auth/register',{email,password})
            .then(response => {
                return response
            })
            .catch(e => console.log(e))
    }
}
export const loginAPI = {
    loginUsers({email,password}){
        return instance.post('/api/auth/login',{email,password})
            .then(response => {
               return response.data
            })
            .catch(e => console.log(e))
    }
}